<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;
use App\Product;
use Validator;
use DB;

class ProductController extends BaseController {

  public function index() {
    $products = Product::all();
    return $this->sendSuccess($products->toArray(), 'Products retrieved successfully.');
  }

  public function findProducts(Request $request) {
    $input = $request->all();

    // $sortField = $input['sortField'];
    // $sortOrder = $input['sortOrder'];
    $pageNumber = $input['pageNumber'];
    $pageSize = $input['pageSize']; 
    $pageSkip = $pageNumber * $pageSize;

    $products = DB::select('select * from products limit ?, ?', [$pageSkip, $pageSize]);
    $count = DB::table('products')->count();

    $data = array(
      'items' => $products,
      'totalCount' => $count
    );

    return $this->sendSuccess($data, 'Products retrieved successfully.');
  }

  public function show($id) {
    $product = Product::find($id);

    if (is_null($product)) {
      return $this->sendError('User not found.');
    }

    return $this->sendSuccess($product, '');
  }

  public function store(Request $request) {
    $validator = Validator::make($request->all(), [
      'name' => 'required',
      'description' => 'required',
      'price' => 'required',
      'category' => 'required',
    ]);

    if ($validator->fails()) {
      return $this->sendFailed('Validation Error', $validator->errors());
    }

    $input = $request->all();

    $product = Product::create($input);

    return $this->sendSuccess($product, 'Product created successfully.');
  }

  public function update(Request $request, $id) {
    $input = $request->all();
    $product = Product::find($id);
    $product->update($input);

    return $this->sendSuccess($product, 'Product updated successfully');
  }

  public function destroy($id) {
    $product = Product::find($id);
    $product->delete();

    return $this->sendSuccess('', 'Product deleted successfully');
  }

  public function download($id) {
    $product = Product::find($id);

    if (is_null($product)) {
      return $this->sendError('Product not found.');
    }

    $filename = $product->file_name;
    $file = public_path('images/products/').$filename;
    $ext = pathinfo($filename, PATHINFO_EXTENSION);

    if($ext == 'png' || 'PNG'){
      $headers = array(
        'Content-Type' => 'image/png',
      );
    }
    else if($ext == 'jpg' || 'jpeg' || 'JPEG' || 'JPG'){
      $headers = array(
        'Content-Type' => 'image/jpeg',
      );
    }

    return response()->download($file, $filename, $headers);
  }
}
