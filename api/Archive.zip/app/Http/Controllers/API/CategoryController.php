<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;
use App\Category;
use Validator;

class CategoryController extends BaseController {
  public function index() {
    $categories = Category::all();
    return $this->sendSuccess($categories->toArray(), 'Categories retrieved successfully.');
  }

  public function show($id) {
    $category = Category::find($id);

    if (is_null($category)) {
      return $this->sendError('Category not found.');
    }

    return $this->sendSuccess($category, '');
  }

  public function store(Request $request) {
    $validator = Validator::make($request->all(), [
      'name' => 'required',
    ]);

    if ($validator->fails()) {
      return $this->sendFailed('Validation Error', $validator->errors());
    }

    $input = $request->all();

    $category = Category::create($input);

    return $this->sendSuccess($category, 'Category created successfully.');
  }

  public function update(Request $request, $id) {
    $input = $request->all();
    $category = Category::find($id);
    $category->update($input);

    return $this->sendSuccess($category, 'Category updated successfully');
  }

  public function destroy($id) {
    $category = Category::find($id);
    $category->delete();

    return $this->sendSuccess('', 'Category deleted successfully');
  }
}
